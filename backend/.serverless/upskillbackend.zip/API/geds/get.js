"use strict";
const axios = require("axios");

async function getEmployeeInfo(event) {
  const searchValue = event.pathParameters.searchValue;
  console.log(searchValue);

  searchEmployee("Rizvi Rab");
  const returnObject = {
    body: JSON.stringify({
      message: "Reaction was successful",
      code: 200
    }),
    statusCode: 200
  };

  return returnObject;
}

async function searchEmployee(searchValue) {
  const url =
    "https://geds-sage-ssc-spc-apicast-staging.api.canada.ca/gapi/v2/employees?searchValue=" +
    encodeURI(searchValue) +
    "&searchField=9&searchCriterion=2&searchScope=sub&searchFilter=2&maxEntries=1000";
  console.log("URL HERE: " + url);

  axios({
    methon: "get",
    url: url,
    headers: {
      Accept: "application/json",
      "user-key": "1d373575a287c2597f4525d0c26eae7d"
    }
  })
    .then(res => {
      console.log(res);
    })
    .catch(err => {
      console.error(err);
    });
}

module.exports = {
  getEmployeeInfo
};
