const gedsGet = require("./get");

module.exports = {
  getEmployeeInfo: gedsGet.getEmployeeInfo
};
